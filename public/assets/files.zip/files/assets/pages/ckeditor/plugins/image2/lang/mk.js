/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'mk', {
	alt: 'Алтернативен текст',
	btnUpload: 'Прикачи на сервер',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Информации за сликата',
	lockRatio: 'Зачувај пропорција',
	menu: 'Својства на сликата',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Ресетирај големина',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Својства на сликата',
	uploadTab: 'Прикачи',
	urlMissing: 'Недостасува URL-то на сликата.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
