/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'hr', {
	alt: 'Alternativni tekst',
	btnUpload: 'Pošalji na server',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Info slike',
	lockRatio: 'Zaključaj odnos',
	menu: 'Svojstva slika',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Obriši veličinu',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Svojstva slika',
	uploadTab: 'Pošalji',
	urlMissing: 'Nedostaje URL slike.',
	altMissing: 'Alternative text is missing.' // MISSING
} );
