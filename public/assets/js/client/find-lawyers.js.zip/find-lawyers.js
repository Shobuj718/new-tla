(function ($) {
    
    function initMap(markersList) {
      var map = new google.maps.Map(document.getElementById('findLawyersMap'), {
        zoom: 8,
        center: {lat: parseFloat(markersList[0].location.lat), lng: parseFloat(markersList[0].location.lng)}
      });
    
      setMarkers(map, markersList);
    }
    
    function setMarkers(map, markersList) {
        
        for (var i = 0; i < markersList.length; i++) {
            var latLong = {lat: parseFloat(markersList[i].location.lat), lng: parseFloat(markersList[i].location.lng)};

            var marker = new google.maps.Marker({
                position: latLong,
                map: map,
                label: markersList[i].count.toString()
            });
        }
    }
    

    function updateSelectedSkillsListView(selectedOptions){
        $('#selectedSkillsList li').remove();
        for(let i = 0; i < selectedOptions.length; i++){
            $('#selectedSkillsList').append('<li class="list-inline-item"><span class="badge badge-pill badge-success">'+selectedOptions[i].text+' <span style="cursor: pointer;"' +
                ' class="removeSkillFromList" data-id="'+selectedOptions[i].id+'"><i' +
                ' class="fa fa-close"></i></span></span></li>')
        }
    }
    
    function updateSelectedLocationsListView(selectedOptions){
        $('#selectedLocationsList li').remove();
        for(let i = 0; i < selectedOptions.length; i++){
            $('#selectedLocationsList').append('<li class="list-inline-item"><span class="badge badge-pill badge-success">'+selectedOptions[i].text+' <span style="cursor: pointer;"' +
                ' class="removeSkillFromList" data-id="'+selectedOptions[i].id+'"><i' +
                ' class="fa fa-close"></i></span></span></li>')
        }
    }

    function updateUiWithLawyers(lawyers){
        let profileList = '';
        let markersList = [];
        
        for(let i=0; i < lawyers.length; i++){
            
            let sigleProfile = '';
            
            let totalRating = 0;
            let rating = 0;
            
            if(lawyers[i].reviews.length){
                for(let j = 0; j < lawyers[i].reviews.length; j++){
                    totalRating += parseInt(lawyers[i].reviews[j].star);
                }
                
                rating = Math.round(totalRating/lawyers[i].reviews.length);
            }
            
            let starRatingHtml = '<li class="rat">';
            
            if(rating){
                for(let k = 0; k < rating; k++){
                    starRatingHtml += '<i class="fa fa-star marked"></i>';
                }
                
                for(let l = 0; l < 5-rating; l++){
                    starRatingHtml = '<i class="fa fa-star"></i>';
                }
            }
            
            starRatingHtml += '</li>';
            
            sigleProfile += '<div class="lawyer_profile_box project_box">';
            sigleProfile +=     '<div class="row">';
            sigleProfile +=         '<div class="col-lg-2">';
            sigleProfile +=             '<div class="profile_img">';
            sigleProfile +=                 '<img src="'+window.location.origin+'/'+lawyers[i].avatar+'" alt="Profile Photo">';
            sigleProfile +=                 '<i class="fa fa-check"></i>';
            sigleProfile +=             '</div>';
            sigleProfile +=         '</div>';
            sigleProfile +=         '<div class="col-lg-5">';
            sigleProfile +=             '<div class="lawyer_name">';
            sigleProfile +=                 '<h4><a href="'+window.location.origin+'/'+lawyers[i].username+'">'+lawyers[i].first_name+' '+lawyers[i].last_name.split("")[0]+'.</a></h4>';
            
            if(lawyers[i].professional_title){
                sigleProfile +=                 '<p>'+lawyers[i].professional_title+'</p>';    
            }
            
            sigleProfile +=             '</div>';
            
            if(rating){
                sigleProfile +=             '<div class="lawyer_rat">';
                sigleProfile +=                 '<ul class="ratings">';
                sigleProfile +=                         '<li class="feedback">'+rating+'</li>';
                sigleProfile +=                         starRatingHtml;
                sigleProfile +=                     '</ul>';
                sigleProfile +=             '</div>';
            }
            
            sigleProfile +=         '</div>';
            sigleProfile +=         '<div class="col-lg-5">';
            sigleProfile +=             '<div class="lawyer_info" style="display: flex;flex-direction: row-reverse;">';
            
            if(lawyers[i].location){
                sigleProfile +=                 ''+lawyers[i].location.city+' '+lawyers[i].location.country+' <i style="margin-top: 4px; margin-right: 10px;" class="fa fa-map-marker"></i>';    
            }
            
            sigleProfile +=             '</div>';
            sigleProfile +=             '<div class="project_btn">';
            sigleProfile +=                 '<a href="'+window.location.origin+'/'+lawyers[i].username+'" class="boxed_btn">View Profile</a>';
            sigleProfile +=             '</div>';
            sigleProfile +=         '</div>';
            sigleProfile +=     '<div class="clearfix"></div>';
            sigleProfile +=     '</div>';
            sigleProfile += '</div>';
            
            if(lawyers[i].location){
                let existingMarkerIndex = markersList.findIndex(function(marker){
                    return marker.location.id == lawyers[i].location.id;
                });
                
                if(existingMarkerIndex > -1){
                    markersList[existingMarkerIndex].count += 1; 
                }
                
                if(existingMarkerIndex == -1){
                    markersList.push({location: lawyers[i].location, count: 1});    
                }
                
            }
            
            profileList += sigleProfile;
        }
        
        $('#lawyerProfileList').html(profileList);
        
        if(markersList.length){
            initMap(markersList);    
        }
        
    }

    function getAndUpdateLawyersList(){
        let selectedSkills = $('#skillsNeeded').val();
        let selectedLocation = $('#caseLocation').val();
        let data = {
                selectedSkills: selectedSkills,
                selectedLocation: selectedLocation
            };
            
        if(page){
            data.page = page;
        }
        
        $.ajax({
            method: "get",
            url: '/search-lawyers',
            data: data
        }).done(function(data){
            
            $('#lawyersFound').html(data.lawyers.total);
            
            updateUiWithLawyers(data.lawyers.data);
            
            $('#pagination').html(data.pagination_links);
            console.log(data);
            
        }).fail(function(data){
            
        });
    }

    $(document).ready(function () {
        
        getAndUpdateLawyersList();
        
        $('#selectedSkillsList').on('click', '.removeSkillFromList', function(e){
            e.preventDefault();
            let idToRemove = $(this).data("id");
            let currentlySelected = $('#skillsNeeded').val();
            let idToRemoveIndex = currentlySelected.indexOf(idToRemove.toString());

            if (idToRemoveIndex > -1) {
                currentlySelected.splice(idToRemoveIndex, 1);
            }

            $('#skillsNeeded').selectpicker('val', currentlySelected);
        });
        
        $('#selectedLocationsList').on('click', '.removeSkillFromList', function(e){
            e.preventDefault();
            let idToRemove = $(this).data("id");
            let currentlySelected = $('#caseLocation').val();
            let idToRemoveIndex = currentlySelected.indexOf(idToRemove.toString());

            if (idToRemoveIndex > -1) {
                currentlySelected.splice(idToRemoveIndex, 1);
            }

            $('#caseLocation').selectpicker('val', currentlySelected);
        });

        $('#skillsNeeded').selectpicker({
            "liveSearch": true,
            "size": 5,
            "liveSearchPlaceholder": "e.g. Family law",
            "noneSelectedText": "Select required skills"
        });

        $('#caseLocation').selectpicker({
            "liveSearch": true,
            "size": 5,
            "liveSearchPlaceholder": "e.g. Perth, Australia",
            "noneSelectedText": "Select location"
        });


        $('#skillsNeeded').on('changed.bs.select', function(e){
            let selections = $('#skillsNeeded option:selected');
            let selectedOptions = [];
            for(let i = 0; i < selections.length; i++){
                let obj = {};
                obj.id = $(selections[i]).val();
                obj.text = $(selections[i]).text();
                selectedOptions.push(obj);
            }

            updateSelectedSkillsListView(selectedOptions);
            
            
            getAndUpdateLawyersList();
        });
        
        $('#caseLocation').on('changed.bs.select', function(e){
            let selections = $('#caseLocation option:selected');
            let selectedOptions = [];
            for(let i = 0; i < selections.length; i++){
                let obj = {};
                obj.id = $(selections[i]).val();
                obj.text = $(selections[i]).text();
                selectedOptions.push(obj);
            }

            updateSelectedLocationsListView(selectedOptions);
            
        
            getAndUpdateLawyersList();
        });
    });
})(jQuery);