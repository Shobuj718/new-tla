(function ($) {
    
    let priceRange = [];
    
    function strip(html) {
        
        var tmp = document.createElement("DIV");
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || "";
    }
    
    function stripTagsAndShorten(str) {
        return strip(str).substring(0, 255);
    }
    
    function initMap(markersList) {
      var map = new google.maps.Map(document.getElementById('findCasesMap'), {
        zoom: 8,
        center: {lat: parseFloat(markersList[0].location.lat), lng: parseFloat(markersList[0].location.lng)}
      });
    
      setMarkers(map, markersList);
    }
    
    function setMarkers(map, markersList) {
        
        for (var i = 0; i < markersList.length; i++) {
            var latLong = {lat: parseFloat(markersList[i].location.lat), lng: parseFloat(markersList[i].location.lng)};

            var marker = new google.maps.Marker({
                position: latLong,
                map: map,
                label: markersList[i].count.toString()
            });
        }
    }
    

    function updateSelectedSkillsListView(selectedOptions){
        $('#selectedSkillsList li').remove();
        for(let i = 0; i < selectedOptions.length; i++){
            $('#selectedSkillsList').append('<li class="list-inline-item"><span class="badge badge-pill badge-success">'+selectedOptions[i].text+' <span style="cursor: pointer;"' +
                ' class="removeSkillFromList" data-id="'+selectedOptions[i].id+'"><i' +
                ' class="fa fa-close"></i></span></span></li>')
        }
    }

    // this is a new feature for case searching since things are changing
    
    function updateSelectedLocationsListView(selectedOptions){
        $('#selectedLocationsList li').remove();
        for(let i = 0; i < selectedOptions.length; i++){
            $('#selectedLocationsList').append('<li class="list-inline-item"><span class="badge badge-pill badge-success">'+selectedOptions[i].text+' <span style="cursor: pointer;"' +
                ' class="removeSkillFromList" data-id="'+selectedOptions[i].id+'"><i' +
                ' class="fa fa-close"></i></span></span></li>')
        }
    }

    // ----------------------------------------- UI ---------------------------------------------
    
    function updateUiWithCases(cases){
        let caseLists = '';
        let markersList = [];

        for(let i = 0; i < cases.length; i++){
            let singleCase = '';
            let now = moment();
            let then = moment(cases[i].created_at, 'YYYY-MM-DD HH:mm:ss');
            
            singleCase +='<div class="project_box">';
            singleCase +=    '<div class="row">';
            singleCase +=        '<div class="col-lg-9">';
            singleCase +=            '<h6><a href="'+window.location.origin+'/case/'+cases[i].slug+'">'+cases[i].title+'</a></h6>';
            singleCase +=            '<div class="project_details">';
            singleCase +=                '<ul>';
            singleCase +=                    '<li><a href="#"><i class="fa fa-user"></i>'+cases[i].client.first_name+' '+cases[i].client.last_name.split("")[0]+'.</a></li>';
            
            // If case location field is required, no need to add this logic here.
            if(cases[i].location){
                singleCase +=                    '<li><a href="#"><i class="fa fa-map-marker"></i>'+cases[i].location.city+'</a></li>';
            }
            
            singleCase +=                    '<li><a href="#"><i class="fa fa-clock-o"></i>'+moment.duration(now.diff(then)).humanize()+'</a></li>';
            singleCase +=                '</ul>';
            singleCase +=            '</div>';
            singleCase +=            '<p >'+stripTagsAndShorten(cases[i].description)+'</p>';
            singleCase +=            '<div class="project_tags">';
            singleCase +=                '<ul>';
            
            if(cases[i].skills.length){
                for(let j=0; j < cases[i].skills.length; j++){
                    singleCase +=                   '<li><span class="badge badge-pill badge-success">'+cases[i].skills[j].name+'</span></li>';
                }
            }
            
            singleCase +=                '</ul>';
            singleCase +=            '</div>';
            singleCase +=        '</div>';
            singleCase +=        '<div class="col-lg-3">';
            singleCase +=            '<div class="project_budget">';
            singleCase +=                'Budget';
            singleCase +=                '<div class="project_price">';
            singleCase +=                    '$'+cases[i].budget+'';
            singleCase +=                '</div>';
            singleCase +=            '</div>';
            singleCase +=            '<div class="project_btn">';
            
            // singleCase +=                '<a href="#" class="boxed_btn">Bid Now</a>';
            
            singleCase +=            '</div>';
            singleCase +=        '</div>';
            singleCase +=    '</div>';
            singleCase +='</div>';
            
            caseLists += singleCase;
            
            let existingMarkerIndex = markersList.findIndex(function(marker){
                return marker.location.id == cases[i].location.id;
            });
            
            if(existingMarkerIndex > -1){
                markersList[existingMarkerIndex].count += 1; 
            }
            
            if(existingMarkerIndex == -1){
                markersList.push({location: cases[i].location, count: 1});    
            }
        }
        
        $('#caseList').html(caseLists);
        
        if(markersList.length){
            initMap(markersList);    
        }
   }
    


    function getAndUpdateCasesList(){
        
        let selectedSkills = $('#skillsNeeded').val();
        let selectedLocation = $('#location').val();
        
        console.log(selectedLocation);
        
        let selectedTimeframe = $('#timeframe').val();
        let timeframe = selectedTimeframe.split('-');
        
        let startDate = timeframe[0].split('/');
        startDate.reverse();
        startDate = startDate.join('-').replace(' ', '');
        
        let endDate = timeframe[1].split('/');
        endDate.reverse();
        endDate = endDate.join('-').replace(' ', '');
        
        let lowestPrice = priceRange[0];
        let highestPrice = priceRange[1];
        
        let data = {
                selectedSkills: selectedSkills,
                selectedLocation: selectedLocation,
                startDate: startDate+' 00:00:00',
                endDate: endDate+' 23:59:59',
                lowestPrice: lowestPrice,
                highestPrice: highestPrice
            };
        
        if(page){
            data.page = page;
        }
            
        $.ajax({
            method: "get",
            url: '/search-cases',
            
            data: data
            
        }).done(function(data){
            
            console.log(data);
            
            $('#casesFound').html(data.cases.total);
            
            updateUiWithCases(data.cases.data);
            
            $('#pagination').html(data.pagination_links);
            
        }).fail(function(data){
            
        });
    }

    $(document).ready(function () {
        
        var slider = new Slider('#price-range');
        priceRange = slider.getValue();
        
        slider.on('slideStop', function(e){
            page = 1;
            priceRange = slider.getValue(); 
            getAndUpdateCasesList();
        });
        
        $('#timeframe').on('hide.daterangepicker', function(){
            page = 1;
            getAndUpdateCasesList();
        });
        
        var start = startDateInQuery ? moment(startDateInQuery, "YYYY-MM-DD HH:mm:ss") : moment().subtract(60, 'days');
        var end = endDateInQuery ? moment(endDateInQuery, "YYYY-MM-DD HH:mm:ss") : moment();
    
        function cb(start, end) {
            $('#timeframe').html(start.format('YYYY/MM/DD') + '-' + end.format('YYYY/MM/DD'));
        }
    
        $('#timeframe').daterangepicker({
            startDate: start,
            endDate: end,
            ranges: {
               'Today': [moment(), moment()],
               'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
               'Last 7 Days': [moment().subtract(6, 'days'), moment()],
               'Last 30 Days': [moment().subtract(29, 'days'), moment()],
               'This Month': [moment().startOf('month'), moment().endOf('month')],
               'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            },
            locale: {
                format: 'DD/MM/YYYY'
            }
        }, cb);
    
        cb(start, end);

    
        
        getAndUpdateCasesList();
        
        $('#selectedSkillsList').on('click', '.removeSkillFromList', function(e){
            e.preventDefault();
            let idToRemove = $(this).data("id");
            let currentlySelected = $('#skillsNeeded').val();
            let idToRemoveIndex = currentlySelected.indexOf(idToRemove.toString());

            if (idToRemoveIndex > -1) {
                currentlySelected.splice(idToRemoveIndex, 1);
            }

            $('#skillsNeeded').selectpicker('val', currentlySelected);
        });
        
        $('#selectedLocationsList').on('click', '.removeSkillFromList', function(e){
            e.preventDefault();
            let idToRemove = $(this).data("id");
            let currentlySelected = $('#location').val();
            let idToRemoveIndex = currentlySelected.indexOf(idToRemove.toString());

            if (idToRemoveIndex > -1) {
                currentlySelected.splice(idToRemoveIndex, 1);
            }

            $('#location').selectpicker('val', currentlySelected);
        });

        $('#skillsNeeded').selectpicker({
            "liveSearch": true,
            "size": 5,
            "liveSearchPlaceholder": "e.g. Family law",
            "noneSelectedText": "Select required skills"
        });
        
        $('#location').selectpicker({
            "liveSearch": true,
            "size": 5,
            "liveSearchPlaceholder": "e.g. Perth, Australia",
            "noneSelectedText": "Select location"
        });


        $('#skillsNeeded').on('changed.bs.select', function(e){
            let selections = $('#skillsNeeded option:selected');
            let selectedOptions = [];
            for(let i = 0; i < selections.length; i++){
                let obj = {};
                obj.id = $(selections[i]).val();
                obj.text = $(selections[i]).text();
                selectedOptions.push(obj);
            }

            updateSelectedSkillsListView(selectedOptions);
            page = 1;
            
            getAndUpdateCasesList();
        });
        
        $('#location').on('changed.bs.select', function(e){
            let selections = $('#location option:selected');
            let selectedOptions = [];
            for(let i = 0; i < selections.length; i++){
                let obj = {};
                obj.id = $(selections[i]).val();
                obj.text = $(selections[i]).text();
                selectedOptions.push(obj);
            }
            
            // console.log(selectedOptions);

            updateSelectedLocationsListView(selectedOptions);
            
        
            getAndUpdateCasesList();
        });
    });
})(jQuery);